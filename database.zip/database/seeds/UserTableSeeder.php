<?php

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;

class UserTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('user')->insert([
            'first_name' => 'Adventurer',
            'last_name' => 'Admin',
            'email' => 'ez',
                'password' => bcrypt('secret'),
        ]);
    }
}