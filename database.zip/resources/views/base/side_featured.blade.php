<div class="container">
    <div class="row">
        <div class="col-xs-12">
            <div class="card">
            @foreach($featured as $tour)
                <div class="col-xs-12">
                    kj
                </div>
            @endforeach
            </div>
        </div>
    </div>
</div>