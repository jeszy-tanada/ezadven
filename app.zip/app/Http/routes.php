<?php

/*
|--------------------------------------------------------------------------
| Routes File
|--------------------------------------------------------------------------
|
| Here is where you will register all of the routes in an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

//Route::get('/', function () {
//    return view('welcome');
//});


/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| This route group applies the "web" middleware group to every route
| it contains. The "web" middleware group is defined in your HTTP
| kernel and includes session state, CSRF protection, and more.
|
*/

Route::group(['middleware' => ['web']], function () {
    Route::get('/',  ['as' => 'home', 'uses'=> 'PublicController@index']);
    Route::get('/cp/', ['uses' => 'PublicController@cp']);
    Route::get('/cp/home', ['as' => 'cp_home', 'uses' => 'BaseController@home']);
    Route::get('/cp/countries', ['as' => 'countries', 'uses' => 'BaseController@countries']);
    Route::any('/cp/add/country', ['as' => 'add_country', 'uses' => 'BaseController@add_country']);
    Route::get('/cp/areas', ['as' => 'areas', 'uses' => 'BaseController@areas']);
    Route::any('/cp/add/area', ['as' => 'add_area', 'uses' => 'BaseController@add_area']);
    Route::get('/cp/tours', ['as' => 'tours', 'uses' => 'BaseController@tours']);
    Route::any('/cp/add/tour', ['as' => 'add_tour', 'uses' => 'BaseController@add_tour']);
    Route::any('/cp/edit/tour/{id}', ['as' => 'edit_tour', 'uses' => 'BaseController@edit_tour'], function($id) {})->where('id', '[A-Za-z0-9]+');
    Route::any('/cp/tour/{id}', ['as' => 'tour_view', 'uses' => 'BaseController@tour_view'], function($id) {})->where('id', '[A-Za-z0-9]+');
    Route::any('/cp/inquiries', ['as' => 'inquiries', 'uses' => 'BaseController@inquiries']);




    Route::any('/login/',  ['as' => 'login', 'uses'=> 'PublicController@authenticate']);
    Route::get('/logout',  ['as' => 'logout', 'uses'=> 'PublicController@logout']);








    Route::get('/contact', ['as' => 'contact', 'uses' => 'PublicController@contact']);
    Route::get('/tour', ['as' => 'pub_tours', 'uses' => 'PublicController@tours']);
    Route::any('/tour/{id}', ['as' => 'pub_tour_view', 'uses' => 'PublicController@tour_view'], function($id) {})->where('id', '[A-Za-z0-9]+');
    Route::post('/inquire', ['as' => 'inquire', 'uses' => 'PublicController@inquire']);
//    Route::any('/home/',  ['as' => 'home', 'uses'=> 'BaseController@home']);
//    Route::any('/settings/',  ['as' => 'settings', 'uses'=> 'BaseController@settings']);
//    Route::get('/user/list/',  ['as' => 'user_list', 'uses'=> 'BaseController@user_list']);
//    Route::any('/user/add/', ['as' => 'user_add', 'uses'=> 'BaseController@user_add']);
////    Route::get('/user/add/', ['as' => 'user_add', 'uses'=> 'BaseController@user_add']);
//
//    Route::any('/product/type/add/', ['as' => 'product_type_add', 'uses'=> 'BaseController@product_type_add']);
//
//    Route::get('/product/list/',  ['as' => 'product_list', 'uses'=> 'BaseController@product_list']);
//    Route::any('/product/add/', ['as' => 'product_add', 'uses'=> 'BaseController@product_add']);
//
//    Route::any('/order/add/{id}', ['as' => 'customer_order_add', 'uses' => 'BaseController@customer_order_add'], function($id) {})->where('id', '[A-Za-z0-9]+');
//    Route::any('/order/items/{id}', ['as' => 'order_item_list', 'uses' => 'BaseController@order_item_list'], function($id) {})->where('id', '[A-Za-z0-9]+');
//    Route::any('/order/item/delete', ['as' => 'order_item_delete', 'uses' => 'BaseController@order_item_delete']);
//    Route::any('/order/', ['as' => 'order', 'uses' => 'BaseController@order']);
//    Route::any('/order/add/', ['as' => 'order_add', 'uses' => 'BaseController@order_add']);
//    Route::get('/order/list/', ['as' => 'order_list', 'uses' => 'BaseController@order_list']);
//
//    Route::get('/customer/list/',  ['as' => 'customer_list', 'uses'=> 'BaseController@customer_list']);
//    Route::any('/customer/add/', ['as' => 'customer_add', 'uses'=> 'BaseController@customer_add']);
//
//    Route::get('/cp/master/',  ['as' => 'tarps_list', 'uses'=> 'BaseController@tarps_list']);
//    Route::any('/tarp/add/', ['as' => 'tarp_add', 'uses'=> 'BaseController@tarp_add']);
//    Route::any('/tarp/process/', ['as' => 'tarp_process', 'uses'=> 'BaseController@tarp_process']);
//    Route::get('/cp/processed/',  ['as' => 'processed_list', 'uses'=> 'BaseController@processed_list']);
//    Route::any('/tarp/processed/{id}', ['as' => 'processed_view', 'uses' => 'BaseController@processed_view'], function($id) {})->where('id', '[A-Za-z0-9]+');
//    Route::any('/tarp/add/spoil', ['as' => 'spoil_tarp_add', 'uses'=> 'BaseController@spoil_tarp_add']);
//    Route::any('/tarp/status/change', ['as' => 'status_change', 'uses'=> 'BaseController@status_change']);
});
